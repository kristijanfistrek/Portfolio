const mainMenu = document.getElementById('menu');
const menuContent = document.getElementById('menu-content');

mainMenu.addEventListener('click', function handleClick() {
    if(menuContent.classList.contains('block')) {
        menuContent.classList.remove('block');
    } else {
        menuContent.classList.add('block');
    }
});

function checkStateOfMainMenu() {
    if(menuContent.classList.contains('block')) {
        
    }
}