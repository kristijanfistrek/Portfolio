"use strict"

const firstName = "Kristijan Fištrek";
const occupation = "Software Developer";

const blueTitleElement = document.getElementById('blue');
const whiteTitleElement = document.getElementById('white');

